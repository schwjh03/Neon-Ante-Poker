Neon Ante Poker — 3D Windows preview

Extract the complete ZIP, then run NeonAntePoker.exe.
Windows 10/11, 64-bit. No installer or extra runtime download is required.
This preview includes the modeled table, rounded cards, deck, and chip stacks.
The public 1.2.0 release remains available as an earlier version.

Click cards or press 1-8 to select up to five. Enter plays; Backspace discards.
R sorts by rank; S sorts by suit. H opens the hand reference; Escape opens the menu.
Choose Modes at the top to start Classic, Daily Seed, Relic Draft, or Echo.

Runs save to %LOCALAPPDATA%/NeonAntePoker/run-v2.save.
Browser and Windows saves are separate. Existing compatible Windows saves resume.
This is a single-player score game; it has no real-money wagering.

Original source: https://github.com/schwjh03/Neon-Ante-Poker
Dependencies and their licenses are in THIRD_PARTY.md and licenses/.
